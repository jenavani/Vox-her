import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAH6Yeh51y4itp7vojuy1ntxR7niMvQknU",
            authDomain: "gdsv-a92f3.firebaseapp.com",
            projectId: "gdsv-a92f3",
            storageBucket: "gdsv-a92f3.appspot.com",
            messagingSenderId: "351177602931",
            appId: "1:351177602931:web:939dfd4c724e299bed7706",
            measurementId: "G-PR5H5BX6Q1"));
  } else {
    await Firebase.initializeApp();
  }
}
