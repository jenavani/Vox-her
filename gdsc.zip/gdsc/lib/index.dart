// Export pages
export '/pages/problemlist/problemlist_widget.dart' show ProblemlistWidget;
export '/pages/act1/act1_widget.dart' show Act1Widget;
export '/pages/feature1/feature1_widget.dart' show Feature1Widget;
export '/pages/ipc1/ipc1_widget.dart' show Ipc1Widget;
export '/pages/casestudy1/casestudy1_widget.dart' show Casestudy1Widget;
export '/pages/advocate1/advocate1_widget.dart' show Advocate1Widget;
export '/pages/act1_copy/act1_copy_widget.dart' show Act1CopyWidget;
export '/pages/feature1_copy/feature1_copy_widget.dart' show Feature1CopyWidget;
export '/pages/i_p_c1_copy/i_p_c1_copy_widget.dart' show IPC1CopyWidget;
export '/pages/casestudy1_copy/casestudy1_copy_widget.dart'
    show Casestudy1CopyWidget;
export '/pages/advocate1_copy/advocate1_copy_widget.dart'
    show Advocate1CopyWidget;
export '/pages/dashboard6/dashboard6_widget.dart' show Dashboard6Widget;
export '/pages/details14_destination/details14_destination_widget.dart'
    show Details14DestinationWidget;
